import 'package:app/screens/homepage_screen.dart';
import 'package:app/screens/user_screen.dart';
import 'package:flutter/material.dart';

class DrawerHelpers extends StatefulWidget {
  const DrawerHelpers({super.key});

  @override
  State<DrawerHelpers> createState() => _DrawerHelpersState();
}

class _DrawerHelpersState extends State<DrawerHelpers> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          UserAccountsDrawerHeader(
            accountName: Text('Matheus Morilha'), 
            accountEmail: Text('matheus.morilha@gmail.com'),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.blue,
              child: Text('M'),
            ),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Página Inicial'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => HomepageScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text('Usuários'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => UserScreen()));
            },
          )
        ],
      ),
    );
  }
}